# Petrol Ofisi V/Max Diesel Takip

Bu proje Petrol Ofisi fiyat sayfalarından yalnızca **V/Max Diesel** fiyatını takip eder.

Takip edilen lokasyonlar:

- Bursa / Karacabey
- Aksaray / Aksaray
- İzmir / Tire
- Bingöl / Bingöl

Sistem GitHub Actions ile 30 dakikada bir çalışır. Fiyat değişikliği varsa Outlook e-posta adresine mail gönderir. Değişiklik yoksa mail göndermez.

## Dosyalar

```text
po_check.py
requirements.txt
data/last_prices.json
.github/workflows/check.yml
```

## GitHub'a yükleme

GitHub reposunda **Add file > Upload files** seçeneğiyle bu klasördeki dosyaları yükleyebilirsin.

Önemli: `.github/workflows/check.yml` dosyasının aynı klasör yapısıyla yüklenmesi gerekir.

## Outlook ayarları

Repo içinde şu yola git:

**Settings > Secrets and variables > Actions > New repository secret**

Aşağıdaki 3 secret'ı ekle:

### 1. OUTLOOK_EMAIL

Outlook adresin.

Örnek:

```text
buse_aydinn@outlook.com
```

### 2. OUTLOOK_PASSWORD

Outlook şifren veya Microsoft uygulama şifren.

Not: Hesabında iki aşamalı doğrulama açıksa normal şifre yerine uygulama şifresi gerekebilir.

### 3. TO_EMAIL

Bildirimlerin gideceği e-posta adresi. Outlook adresinle aynı olabilir.

## İlk test

Repo içinde **Actions** sekmesine gir.

**Petrol Ofisi VMax Diesel Takip** workflow'unu aç.

**Run workflow** de.

Test maili için:

```text
test_email = true
```

İlk mevcut fiyatları mail olarak almak için:

```text
send_baseline = true
```

## Çalışma mantığı

1. Petrol Ofisi il fiyat sayfalarını okur.
2. İlgili ilçedeki V/Max Diesel fiyatını bulur.
3. `data/last_prices.json` içindeki son kayıtla karşılaştırır.
4. Değişiklik varsa mail gönderir.
5. Yeni fiyatları `data/last_prices.json` dosyasına kaydeder.

## Sorun olursa

Actions > ilgili çalışma > log ekranında hata mesajı görünür.

En sık hata Outlook SMTP girişidir. Bu durumda Microsoft hesabında uygulama şifresi oluşturmak gerekebilir.
