import argparse
import json
import os
import re
import smtplib
import sys
from dataclasses import dataclass
from datetime import datetime
from email.mime.text import MIMEText
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://www.petrolofisi.com.tr"
STATE_FILE = Path("data/last_prices.json")
PRODUCT_NAME = "V/Max Diesel"

LOCATIONS = [
    {"label": "Bursa / Karacabey", "city_slug": "bursa", "district": "KARACABEY"},
    {"label": "Aksaray / Aksaray", "city_slug": "aksaray", "district": "AKSARAY"},
    {"label": "İzmir / Tire", "city_slug": "izmir", "district": "TIRE"},
    {"label": "Bingöl / Bingöl", "city_slug": "bingol", "district": "BINGOL"},
]

@dataclass
class PriceRecord:
    label: str
    city_slug: str
    district: str
    product: str
    price: str
    unit: str
    url: str


def normalize(text: str) -> str:
    table = str.maketrans({
        "ı": "i", "İ": "I", "ğ": "g", "Ğ": "G", "ü": "u", "Ü": "U",
        "ş": "s", "Ş": "S", "ö": "o", "Ö": "O", "ç": "c", "Ç": "C",
    })
    return re.sub(r"\s+", " ", text.translate(table).strip()).upper()


def city_url(city_slug: str) -> str:
    return f"{BASE_URL}/akaryakit-fiyatlari/{city_slug}-akaryakit-fiyatlari"


def fetch_html(url: str) -> str:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
        ),
        "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    last_error = None
    for _ in range(3):
        try:
            response = requests.get(url, headers=headers, timeout=35)
            response.raise_for_status()
            return response.text
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f"Sayfa okunamadı: {url} - {last_error}")


def text_lines_from_html(html: str) -> List[str]:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    return [line.strip() for line in soup.get_text("\n", strip=True).splitlines() if line.strip()]


def parse_price(lines: List[str], district: str, product: str) -> Optional[tuple[str, str]]:
    wanted_district = normalize(district)
    wanted_product = normalize(product)

    district_indexes = [i for i, line in enumerate(lines) if normalize(line) == wanted_district]
    for start in district_indexes:
        window = lines[start + 1 : start + 80]
        for idx, line in enumerate(window):
            if normalize(line) == wanted_product:
                for following in window[idx + 1 : idx + 5]:
                    match = re.search(r"(\d{1,3}(?:[.,]\d{1,3})?)\s*(TL\s*/\s*LT|TL/LT|₺)?", following, re.I)
                    if match:
                        price = match.group(1).replace(",", ".")
                        unit = (match.group(2) or "TL/LT").replace(" ", "").upper()
                        return price, unit
    return None


def collect_prices() -> Dict[str, dict]:
    results: Dict[str, dict] = {}
    errors = []

    for location in LOCATIONS:
        url = city_url(location["city_slug"])
        try:
            html = fetch_html(url)
            lines = text_lines_from_html(html)
            parsed = parse_price(lines, location["district"], PRODUCT_NAME)
            if not parsed:
                raise ValueError(f"{location['label']} için {PRODUCT_NAME} bulunamadı.")
            price, unit = parsed
            rec = PriceRecord(
                label=location["label"],
                city_slug=location["city_slug"],
                district=location["district"],
                product=PRODUCT_NAME,
                price=price,
                unit=unit,
                url=url,
            )
            results[rec.label] = rec.__dict__
        except Exception as exc:
            errors.append(f"{location['label']}: {exc}")

    if errors:
        raise RuntimeError("Bazı lokasyonlar okunamadı:\n" + "\n".join(errors))
    return results


def load_state() -> dict:
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    return {"prices": {}, "updated_at": None}


def save_state(prices: Dict[str, dict]) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "product": PRODUCT_NAME,
        "prices": prices,
    }
    STATE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def find_changes(old_prices: Dict[str, dict], new_prices: Dict[str, dict]) -> List[dict]:
    changes = []
    for label, new in new_prices.items():
        old = old_prices.get(label)
        if old and old.get("price") != new.get("price"):
            changes.append({
                "label": label,
                "product": PRODUCT_NAME,
                "old_price": old.get("price"),
                "new_price": new.get("price"),
                "unit": new.get("unit", "TL/LT"),
                "url": new.get("url"),
            })
    return changes


def make_email_body(changes: List[dict], all_prices: Dict[str, dict]) -> str:
    now = datetime.now().strftime("%d.%m.%Y %H:%M")
    lines = [
        "Petrol Ofisi V/Max Diesel fiyat değişikliği tespit edildi.",
        f"Kontrol zamanı: {now}",
        "",
        "Değişen fiyatlar:",
    ]
    for c in changes:
        try:
            delta = float(c["new_price"]) - float(c["old_price"])
            delta_text = f" ({delta:+.2f})"
        except Exception:
            delta_text = ""
        lines.append(f"- {c['label']}: {c['old_price']} → {c['new_price']} {c['unit']}{delta_text}")

    lines += ["", "Güncel takip edilen fiyatlar:"]
    for label, item in all_prices.items():
        lines.append(f"- {label}: {item['price']} {item.get('unit', 'TL/LT')}")

    lines += ["", "Kaynak sayfalar:"]
    for item in all_prices.values():
        lines.append(f"- {item['label']}: {item['url']}")
    return "\n".join(lines)


def send_email(subject: str, body: str) -> None:
    sender = os.environ.get("OUTLOOK_EMAIL")
    password = os.environ.get("OUTLOOK_PASSWORD")
    receiver = os.environ.get("TO_EMAIL") or sender
    smtp_host = os.environ.get("SMTP_HOST", "smtp-mail.outlook.com")
    smtp_port = int(os.environ.get("SMTP_PORT", "587"))

    if not sender or not password or not receiver:
        raise RuntimeError("OUTLOOK_EMAIL, OUTLOOK_PASSWORD ve TO_EMAIL GitHub Secrets olarak tanımlanmalı.")

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = receiver

    with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(sender, password)
        server.send_message(msg)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-email", action="store_true", help="SMTP ayarlarını test etmek için mail gönderir.")
    parser.add_argument("--send-baseline", action="store_true", help="İlk kayıtta mevcut fiyatları mail gönderir.")
    args = parser.parse_args()

    if args.test_email:
        send_email("Petrol Ofisi takip sistemi test maili", "Test başarılı. Outlook SMTP bağlantısı çalışıyor.")
        print("Test maili gönderildi.")
        return 0

    old_state = load_state()
    old_prices = old_state.get("prices", {})
    new_prices = collect_prices()

    changes = find_changes(old_prices, new_prices)
    first_run = not bool(old_prices)

    if changes:
        body = make_email_body(changes, new_prices)
        send_email("Petrol Ofisi V/Max Diesel Fiyat Değişikliği", body)
        print(f"{len(changes)} fiyat değişikliği için mail gönderildi.")
    elif first_run and args.send_baseline:
        body = "İlk fiyat kaydı oluşturuldu.\n\n" + "\n".join(
            f"- {label}: {item['price']} {item.get('unit', 'TL/LT')}" for label, item in new_prices.items()
        )
        send_email("Petrol Ofisi V/Max Diesel İlk Kayıt", body)
        print("İlk kayıt maili gönderildi.")
    else:
        print("Fiyat değişikliği yok.")

    save_state(new_prices)
    print(json.dumps(new_prices, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
